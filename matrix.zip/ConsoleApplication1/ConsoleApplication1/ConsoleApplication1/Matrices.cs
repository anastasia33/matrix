﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Matrix
    {
        private double[,] _model;
        public int Height
        {
            get
            {
                return this._model.GetLength(0);
            }
            set
            {
                throw new Exception("Nelzja zadat' wysotu");
            }
        }
        public double[][] Rows
        {
            get
            {
                // sozdajem peremennuju s rezultatom
                double[][] rows = new double[this.Height][];
                // написать функцию, которая возвращает массив из массивов массив[строки][элементы]
                for (int i = 0; i < this.Height; i++)
                {
                    // sozdajem odin konkretnyj rjad
                    double[] row = new double[this.Width];
                    for (int j = 0; j < this.Width; j++) row[j] = this._model[i, j];
                    rows[i] = row;
                }
                return rows;
            }
            set
            {
                
                // написать функцию, которая приводит массив из массивов строк в двумерный массив и записывает его в модель матрицы
            }
        }

        public double[][] Cols
        { 
            get
            {
                double[][] cols = new double[this.Width][];
                
                for (int i = 0; i < this.Width; i++)
                {
                    double[] col = new double[this.Height];
                    for (int j = 0; j < this.Height; j++) col[j] = this._model[j, i];
                    cols[i] = col;
                }
                return cols;
              //  return new double[this.Height][];
                // написать функцию, которая возвращает массив из массивов массив[столбцы][элементы]
            }
            set
            {
                // написать функцию, которая приводит массив из массивов столбцов в двумерный массив и записывает его в модель матрицы
            }
        }

        public int[] CountZerosByRows()
        {
            int[] result = new int[Height];
            for(int i = 0; i< Rows.Length; i++)
            {
                int j = 0;
                foreach (double cell in Rows[i])
                {
                    if (cell == 0) { j += 1; }

                }
                result[i] = j;
            }
            return result;
        }

        public int[] CountZerosByCols()
        {
           
            return this.Transponation().CountZerosByRows();
        }


        public int Width
        {
            get
            {
                return this._model.GetLength(1);
            }
            set
            {
                throw new Exception("Nelzja zadat' schirinu");
            }
        }
        
        // public double Determinant;
        // bool IsQuadratic;
        public Matrix(double[,] model)
        {
            this._model = model;
        }

        public double Determinantion()
        {
            // TODO: убрать отладочную матрицу, реализовать вычисления
            // Проверяем, квадратная ли матрица
            // Проверяем размерность: 1 - возвращаем this[0,0]
            // 2 - перемножаем диагонали
            // 3 - проверяем в каких рядах или столбцах сколько нулей - если нули есть - раскладываем по наиболее нулевому ряду
            // 4 и более - проверяем в каких рядах или столбцах сколько нулей- если нули есть - раскладываем по наиболее нулевому ряду
            // если нет - по любому
            if (Width != Height) throw new Exception("Blad");

            if (Width == 1) return this._model[0,0];
            if (Width == 2) return _model[0, 0] * _model[1, 1] - _model[1, 0] * _model[0, 1];
            if (Width == 3)
            {
                return _model[0, 0] * _model[1, 1] * _model[2, 2]
                       + _model[0, 1] * _model[1, 2] * _model[2, 0]
                       + _model[1, 0] * _model[2, 1] * _model[0, 2]
                       - _model[2, 0] * _model[1, 1] * _model[0, 2]
                       - _model[1, 0] * _model[0, 1] * _model[2, 2]
                       - _model[0, 0] * _model[2, 1] * _model[1, 2];
            }
            else
            {
                double det = 0;
                foreach (Tuple<double, Matrix> item in this.Decompose())
                    det += item.Item1 * item.Item2.Determinantion();
                return det;
            }
        }

        public Tuple<double, Matrix> Decompose1(int row, int col)
        {
            double Nominal = Math.Pow(-1, (row+1) +( col+1)) * this._model[row,col];
            double[,] NewMatrix = new double[Width - 1, Height - 1];

            int CurrentHeight = 0, CurrentWidth = 0;
            for (int i = 0; i < Height; i++)
            {
                if (i != row)
                {
                    for (int j = 0; j < Width; j++)
                    {
                        if(j != col)
                        {
                            NewMatrix[CurrentHeight, CurrentWidth] = _model[i, j];
                            CurrentWidth++;
                        }
                    }
                    CurrentHeight++;
                    CurrentWidth = 0;
                }
            }
            return new Tuple<double, Matrix>(
                Nominal,
                new Matrix(NewMatrix)
            );
        }

        public List<Tuple<double, Matrix>> Decompose()
        {
            int numberOfElements;
            int ElementsInCols = Width - CountZerosByCols().Max();
            int ElementsInRows = Height - CountZerosByRows().Max();

            bool byCols = ElementsInCols < ElementsInRows;
            if (byCols) numberOfElements = ElementsInCols;
            else numberOfElements = ElementsInRows;

            List<Tuple<double, Matrix>> result = new List<Tuple<double, Matrix>>();
            if (byCols)
            {
                // raskladuvaem po kolonke
                int i = Array.IndexOf(CountZerosByRows() ,CountZerosByCols().Max());
                Console.WriteLine("i={0}", i);
                for (int j = 0; j < Width; j++)
                {
                    Tuple<double, Matrix> item = Decompose1(i, j);
                    if (item.Item1 != 0)
                        result.Add(item);
                }
            }
            else {
                //raskladuvaem po riadu
                int j = Array.IndexOf(CountZerosByCols(), CountZerosByRows().Max());
                Console.WriteLine("j={0}", j);
                for (int i = 0; i < Height; i++)
                {
                    Tuple<double, Matrix> item = Decompose1(i, j);
                    if (item.Item1 != 0)
                        result.Add(item);
                }
            }
            return result;
        }

        public static Matrix operator *(Matrix Left, Matrix Right)
        {
            if (Left.Width != Right.Height) throw new Exception("Ty nepraw");
            double[,] NewModel = new double[Left.Width, Right.Height];
            for (int i = 0; i < Left._model.GetLength(0); i++)
                for (int j = 0; j < Right._model.GetLength(1); j++)
                {
                    double Sum = 0.0d;
                    for (int k = 0; k < Left.Height; k++) Sum += Left._model[i, k] * Right._model[k, j];
                    NewModel[i, j] = Sum; 
                }
            return new Matrix(NewModel);
        }

        
        public static Matrix operator *(double Left, Matrix Right)
        {
            double[,] NewModel = new double[Right.Width, Right.Height];
            for (int i = 0; i < Right._model.GetLength(0); i++)
                for (int j = 0; j < Right._model.GetLength(1); j++)
                    NewModel[i, j] = Left * Right._model[i, j];
            return new Matrix(NewModel);
        }

        public static Matrix operator *(Matrix Left, double Right)
        {
            return Right * Left;
        }

        
        public static Matrix operator +(Matrix Left, Matrix Right)
        {
            if (Left.Width != Right.Width || Left.Height != Right.Height) throw new Exception("Matrica ne kwadratna!");
            double[,] NewModel = new double[Left.Width, Left.Height];
            for (int i = 0; i < Left._model.GetLength(0); i++)
                for (int j = 0; j < Left._model.GetLength(1); j++)
                    NewModel[i, j] = Left._model[i, j] + Right._model[i, j];
            return new Matrix(NewModel);
        }

        public static Matrix operator -(Matrix Left, Matrix Right)
        {
            return Left + (-1) * Right;
        }
        
        public Matrix Transponation ()
        {

            double[,] NewModel = new double[this.Height, this.Width];
            for (int i = 0; i < this._model.GetLength(0); i++)
                for (int j = 0; j < this._model.GetLength(1); j++)
                    NewModel[i, j] = this._model[j, i];
            return  new Matrix(NewModel);
        }
        
        public override string ToString()
        {
            string result = "[";
            for (int i = 0; i < this.Width; i++) {
                result += "\n";
                for (int j = 0; j < this.Height; j++)
                    result += " " + this._model[i, j].ToString();
            }
            return result + "\n]";
        }
    }
}
