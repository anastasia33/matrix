﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Matrix A = new Matrix(new double[2, 3] {
                { 1.0, 2.0, 3.0},
                { 0.0, 1.0, 4.0}
            });

            Matrix B = new Matrix(new double[3, 3] {
                { 2.0, 2.0, 3.0},
                { 4.0, 1.0, 4.0},
                { 1.0, 3.0, 1.0}
            });
            Console.WriteLine(A.Determinantion());
        }
    }
}
